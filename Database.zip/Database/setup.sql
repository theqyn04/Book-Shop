﻿create database books_shop

CREATE TABLE customers (
    customer_id INT PRIMARY KEY IDENTITY(1,1),
    full_name NVARCHAR(100) NOT NULL,
    [address] NVARCHAR(255),
    phone_number NVARCHAR(15),
    email NVARCHAR(100),
	username NVARCHAR(50) NOT NULL,
    [password] NVARCHAR(255) NOT NULL,
);

-- data for customer

INSERT INTO customers (full_name, [address], phone_number, email, username, [password]) VALUES
(N'Vũ Ngọc Ánh', N'561 Lạc Long Quân, Quy Nhơn, Bình Định', '0256730866', 'Anhvn@gmail.com', 'Anhvn', '123'),
(N'Đinh Quốc Chương', N'23 Phan Bội Châu, Quy Nhơn, Bình Định', '0256730866', 'Chuongdq@gmail.com', 'Chuongdq', '123'),
(N'Trịnh Minh Dương', N'231 Lê Hồng Phong, Quy Nhơn, Bình Định', '0256730866', 'Duongtm@gmail.com', 'Duongtm', '123'),
(N'Lê Đồng Tâm', N'456 Hùng Vương, Quy Nhơn, Bình Định', '0256730866', 'Tamld@gmail.com', 'Tamld', '123'),
(N'Phan Thu Thảo', N'213 Âu Cơ, Quy Nhơn, Bình Định', '0256730866', 'Thaopt@gmail.com', 'Thaopt', '123'),
(N'Đường Mỹ Hà', N'1112 Hùng Vương, Quy Nhơn, Bình Định', '0256730866', 'Hadm@gmail.com', 'Hadm', '123'),
(N'Nguyễn Tuấn Nghĩa', N'21 Đào Duy Tử, Quy Nhơn, Bình Định', '0256730866', 'Nghiant@gmail.com', 'Nghiant', '123'),
(N'Bùi Quang Tuấn', N'Hẻm 220 Nguyễn Thái Học, Quy Nhơn, Bình Định', '0256730866', 'Tuanbq@gmail.com', 'Tuanbq', '123'),
(N'Trần Thu Ngân', N'38 Võ Lai, Quy Nhơn, Bình Định', '0256730866', 'Ngantt@gmail.com', 'Ngantt', '123'),
(N'Nguyễn Thục Ngân', N'456 Trần Hưng Đạo, Quy Nhơn, Bình Định', '0256730866', 'Ngannt@gmail.com', 'Ngannt', '123'),
(N'Bùi Ngọc Bảo Trân', N'561 Lạc Long Quân, Quy Nhơn', '0256730866', 'Tranbnb@gmail.com', 'Tranbnb', '123'),
(N'Phạm Ngọc Quyền', N'17 Trần Thị Kỷ, thị xã An Nhơn, Bình Định', '0256730866', 'Quyenpn@gmail.com', 'Quyenpn', '123'),
(N'Nguyễn Trung Dũng', N'44 Tăng Bạt Hổ, huyện Tuy Phước, Bình Định', '0256730866', 'Dungnt@gmail.com', 'Dungnt', '123'),
(N'Nguyễn Tấn Kiệt', N'521 Tây Sơn, tp.Quy Nhơn, Bình Định', '0256730866', 'Kietnt@gmail.com', 'Kietnt', '123'),
(N'Nguyễn Dương', N'34 Nguyễn Trân, thị xã Hoài Nhơn, Bình Định', '0256730866', 'Duongn@gmail.com', 'Duongn', '123'),
(N'Đoàn Nguyễn Huyền Trang', N'22 Đào Duy Từ, tp.Quy Nhơn, Bình Định', '0256730866', 'Trangdnh@gmail.com', 'Trangdnh', '123'),
(N'Đào Thanh Trúc', N'307 Nguyễn Thị Minh Khai, tp.Quy Nhơn, Bình Định', '0256730866', 'Trucdt@gmail.com', 'Trucdt', '123'),
(N'Trương Thế Cảnh', N'5D Tăng Bạt Hổ, tp.Quy Nhơn, Bình Định', '0256730866', 'Canhtt@gmail.com', 'Canhtt', '123'),
(N'Phạm Quốc Toàn', N'65 Quang Trung, thị xã Hoài Nhơn, Bình Định', '0256730866', 'Toanpq@gmail.com', 'Toanpq', '123'),
(N'Phạm Thanh Trúc', N'295 Trần Phú, thị xã Hoài Nhơn, Bình Định', '0256730866', 'Trucpt@gmail.com', 'Trucpt', '123'),
(N'Phan Bảo Nhi', N'1126 Hùng Vương, tp.Quy Nhơn, Bình Định', '0256730866', 'Nhipb@gmail.com', 'Nhipb', '123'),
(N'Phan Mai Sơn', N'25 Nguyễn Thị Định, tp.Quy Nhơn, Bình Định', '0256730866', 'Sonpm@gmail.com', 'Sonpm', '123'),
(N'Đặng Ngọc Hưng', N'71 Bùi Thị Xuân, huyện Tây Sơn, Bình Định', '0256730866', 'Hungdn@gmail.com', 'Hungdn', '123'),
(N'Lâm Mỹ Linh', N'94 Mai Xuân Thưởng, tp.Quy Nhơn, Bình Định', '0256730866', 'Linhlm@gmail.com', 'Linhlm', '123'),
(N'Lê Thị Chí Thương', N'85/24 Hoàng Văn Thụ, tp.Quy Nhơn, Bình Định', '0256730866', 'Thuongltc@gmail.com', 'Thuongltc', '123'),
(N'Đặng Kiều Duyên', N'67 Chế Lan Viên, thị xã An Nhơn, Bình Định', '0256730866', 'Duyendk@gmail.com', 'Duyendk', '123'),
(N'Vũ Việt Thắng', N'333 Quang Trung, huyện Phù Cát, Bình Định', '0256730866', 'Thangvt@gmail.com', 'Thangvt', '123'),
(N'Vũ Văn Dũng', N'57A Nguyễn Huệ, tp.Quy Nhơn, Bình Định', '0256730866', 'Dungvv@gmail.com', 'Dungvv', '123'),
(N'Phạm Đức Nghĩa', N'114B 31 tháng 3, tp.Quy Nhơn, Bình Định', '0256730866', 'Nghiapd@gmail.com', 'Nghiapd', '123'),
(N'Lê Uyển Nhi', N'Lô 01 Ngọc Hồi, huyện Tây Sơn, Bình Định', '0256730866', 'Nhilu@gmail.com', 'Nhilu', '123');



CREATE TABLE book_types (
    book_type_id INT PRIMARY KEY IDENTITY(1,1),
    book_type_name NVARCHAR(100) NOT NULL,
    [description] NVARCHAR(MAX)
);

-- insert flower type

INSERT INTO book_types (book_type_name, [description]) VALUES
(N'Văn học', N'Sách văn học là thế giới của những câu chuyện đầy cảm xúc, những tác phẩm kinh điển và hiện đại, mang đến cho độc giả những trải nghiệm sâu sắc về cuộc sống, tình yêu, và con người. Từ những tiểu thuyết lãng mạn, truyện ngắn đầy triết lý, đến những tác phẩm văn học kinh điển của các đại văn hào, thể loại này không chỉ giải trí mà còn giúp bạn khám phá những góc khuất của tâm hồn và xã hội.'),
(N'Kinh Tế', N'Sách kinh tế là nguồn tri thức quý giá dành cho những ai muốn hiểu sâu hơn về thế giới tài chính, quản lý, và vận hành của nền kinh tế. Từ những nguyên lý cơ bản đến các chiến lược kinh doanh hiện đại, sách kinh tế mang đến cái nhìn toàn diện về cách thức vận hành của thị trường, doanh nghiệp, và cá nhân trong bối cảnh toàn cầu hóa. Đây là thể loại không thể thiếu cho các nhà quản lý, doanh nhân, sinh viên, và bất kỳ ai quan tâm đến sự phát triển kinh tế.'),
(N'Tâm lý - Kĩ năng sống', N'Sách Kinh tế - Kỹ năng sống là sự kết hợp hoàn hảo giữa kiến thức kinh tế và những bài học thực tiễn về phát triển bản thân. Những cuốn sách này không chỉ giúp bạn hiểu về cách vận hành của thị trường, tài chính, và kinh doanh mà còn trang bị các kỹ năng cần thiết để quản lý thời gian, xây dựng thói quen tích cực, và đạt được sự cân bằng trong cuộc sống. Đây là hành trang không thể thiếu cho những ai muốn thành công cả trong sự nghiệp và đời sống cá nhân.'),
(N'Thiếu nhi', N'Sách thiếu nhi là thế giới kỳ diệu dành cho các độc giả nhỏ tuổi, nơi những câu chuyện đầy màu sắc và nhân vật ngộ nghĩnh mở ra trí tưởng tượng vô tận. Từ những cuốn sách tranh dành cho các bé mới bắt đầu làm quen với sách, đến những truyện dài đầy phiêu lưu và bài học ý nghĩa, sách thiếu nhi không chỉ giúp trẻ phát triển ngôn ngữ, tư duy mà còn nuôi dưỡng tâm hồn và nhân cách. Đây là món quà ý nghĩa dành cho các bé ở mọi lứa tuổi.'),
(N'Sách học ngoại ngữ', N'Sách học ngoại ngữ là người bạn đồng hành không thể thiếu trên hành trình chinh phục ngôn ngữ mới. Từ sách giáo trình cơ bản dành cho người mới bắt đầu, đến tài liệu nâng cao giúp cải thiện kỹ năng nghe, nói, đọc, viết, thể loại này mang đến phương pháp học tập đa dạng và hiệu quả. Dù bạn đang học tiếng Anh, tiếng Nhật, tiếng Hàn, hay bất kỳ ngôn ngữ nào khác, sách học ngoại ngữ sẽ giúp bạn tiến bộ từng ngày.');



CREATE TABLE books (
    book_id INT PRIMARY KEY IDENTITY(1,1),
    book_name NVARCHAR(100) NOT NULL,
    book_type_id INT FOREIGN KEY REFERENCES book_types(book_type_id),
    price DECIMAL(18, 2) NOT NULL,
    stock_quantity INT NOT NULL,
    [description] NVARCHAR(MAX),
    imageURL NVARCHAR(MAX) -- Stores the path to the flower image
);

INSERT INTO books (book_name, book_type_id, price, stock_quantity, [description],	 imageURL) VALUES
(N'Người Đàn Ông Mang Tên OVE (Tái Bản)', 1, 120000, 10, N'Bạn có tin rằng một ông lão cộc cằn, khó tính lại có thể khiến bạn rơi nước mắt vì xúc động? Bạn đã bao giờ nghĩ rằng lòng nhân ái có thể đến từ những con người tưởng chừng khô khan nhất? Một ông lão cộc cằn, một con mèo hoang, vài người hàng xóm phiền phức - tất cả có thể tạo nên một câu chuyện khiến bạn bật khóc?', 'img/product_img/nguoi_dan_ong_mang_ten_ove.jpg'),
(N'Nhà Giả Kim (Tái Bản 2020)', 1, 65000, 15, N'"Nhà Giả Kim" không đơn thuần là một cuốn tiểu thuyết, mà là bản đồ dẫn lối đến giấc mơ, khao khát và định mệnh của mỗi con người. Câu chuyện về chàng trai chăn cừu Santiago không chỉ mang đến những cuộc phiêu lưu hấp dẫn, mà còn mở ra nhiều tầng triết lý sâu sắc về cuộc sống.', 'img/product_img/nha_gia_kim.jpg'),
(N'Nếu Biết Trăm Năm Là Hữu Hạn', 1, 127000, 8, N'Bạn đã bao giờ tự hỏi: Nếu biết trước cuộc đời là hữu hạn, bạn sẽ sống khác đi chứ? Chúng ta luôn nghĩ mình có nhiều thời gian, nhưng thực tế, mọi khoảnh khắc đều đang trôi qua mãi mãi.', 'img/product_img/neu_biet_tram_nam_la_huu_han.jpg'),
(N'Trường Ca Achilles', 1, 109000, 8, N'Lấy cảm hứng từ sử thi Iliad, Madeline Miller đã tái hiện một câu chuyện tình yêu đầy say đắm nhưng cũng nhuốm màu bi kịch giữa hai người anh hùng Hy Lạp trong tác phẩm đầu tay của mình – Trường Ca Achilles.', 'img/product_img/truong_ca_achilles.jpg'),
(N'Tiếng Gọi Chân Trời', 1, 168000, 8, N'Những con người văng mình vào những cuộc đi/về, vào cuộc mất/còn của những chuẩn mực sống, những mối quan hệ ấm lạnh của cuộc đời khi mà giá trị vật chất lên ngôi. Vẫn phong cách quen thuộc: mộc mạc, giàu chất thơ, làm mờ ranh giới thể loại, với “Tiếng gọi chân trời”, Nguyễn Ngọc Tư đưa người đọc chạm đến trạng thái đa chiều của đời sống, mà trung tâm vẫn là thân phận con người, những biến động tâm hồn họ trước biến động xã hội.Các nhân vật trong “Tiếng gọi chân trời” như những cánh diều chao đảo cố níu giữ trạng thái thăng bằng mong manh. Họ, với đôi tay chai sạn, gánh trên vai những khát vọng bình dị, nhưng cũng nặng trĩu mất mát, hy sinh. Và dẫu kiệt quệ, họ vẫn cất bước, vì đâu đó phía cuối chân trời, biết đâu vẫn còn một vệt sáng.', 'img/product_img/tieng_goi_chan_troi.jpg'),
(N'Trốn Lên Mái Nhà Để Khóc - Tặng Kèm Bookmark', 1, 76000, 8, N'Những cơn gió heo may len lỏi vào từng góc phố nhỏ, mùa thu về gợi nhớ bao yêu thương đong đầy, bao xúc cảm dịu dàng của ký ức. Đó là nỗi nhớ đau đáu những hương vị quen thuộc của đồng nội, là hoài niệm bất chợt khi đi trên con đường cũ in dấu bao kỷ niệm... để rồi ta ước có một chuyến tàu kỳ diệu trở về những năm tháng ấy, trở về nơi nương náu bình yên sau những tháng ngày loay hoay để học cách trở thành một người lớn. Bạn sẽ được đắm mình trong những cảm xúc đẹp đẽ xen lẫn những tiếc nuối đầy lắng đọng trong “Trốn lên mái nhà đẻ khóc” của Lam.', 'img/product_img/tron_len_mai_nha_de_khoc.jpg'),
(N'Tiệm Sách Của Nàng - Tặng Kèm Bookmark Photostrip', 1, 87500, 8, N'Bối cảnh là một tiệm sách tại thành phố hiện đại. Nhân vật “anh” xuất hiện trong câu chuyện tình cảm lãng mạn, ở đó có nắng ấm êm, có mưa thành dòng để thả thuyền giấy, những câu thoại vu vơ chỉ hai người mới hiểu, với “một chút hân hoan, một chút dỗi hờn…”', 'img/product_img/tiem_sach_cua_nang.jpg'),
(N'Kế Toán Vỉa Hè', 2, 149000, 8, N'Kế toán và tài chính là nỗi đau chung của rất nhiều doanh nghiệp nhỏ. Ngôn ngữ tài chính dường như là điều bí ẩn nhất của thế giới. Vô số tính toán và ý đồ được cài cắm sau các con số, mà thậm chí người kinh doanh nhiều năm cũng không thể nào bóc tách nổi.', 'img/product_img/ke_toan_via_he.jpg'),
(N'MBA Bằng Hình - The Visual MBA', 2, 141000, 8, N'Jason Barron, MBA, là một nhà lãnh đạo đầy sáng tạo tập trung vào chiến lược sản phẩm số và trải nghiệm người dùng. Ông cũng là đồng sự sáng lập nên công ty khởi nghiệp LowestMed, vốn được RetailMeNot thâu tóm vào năm 2018, và hiện nay đang làm quản lý cấp cao cho một tổ chức phi lợi nhuận lớn chuyên về các sản phẩm số cung cấp cho hàng triệu người dùng trên khắp thế giới.', 'img/product_img/mba_bang_hinh.jpg'),
(N'48 Nguyên Tắc Chủ Chốt Của Quyền Lực (Tái Bản 2020)', 2, 154000, 8, N'Quyền lực có sức hấp dẫn vô cùng mạnh mẽ đối với con người trong mọi thời, ở mọi nơi, với mọi giai tầng. Lịch sử xét cho cùng là cuộc đấu tranh triền miên để giành cho bằng được quyền lực cai trị của các tập đoàn thống trị, từ cổ chí kim, từ đông sang tây.', 'img/product_img/nguyen_tac_chu_chot.jpg'),
(N'AI 5.0 - Nhanh Hơn, Dễ Hơn, Rẻ Hơn, Chính Xác Hơn', 2, 156000, 8, N'Trí tuệ nhân tạo (AI) đã tác động đến nhiều ngành công nghiệp trên toàn thế giới như: tài chính ngân hàng, dược phẩm, ô tô, công nghệ y tế, sản xuất và bán lẻ. Nhưng nó chỉ mới bắt đầu cuộc phiêu lưu hướng tới những dự đoán rẻ hơn, tốt hơn và nhanh hơn nhằm thúc đẩy các quyết định kinh doanh chiến lược.', 'img/product_img/ai-5.0-bia-1.jpg'),
(N'Bí Mật Tư Duy Triệu Phú (Tái Bản 2021)', 2, 78000, 8, N'Trong cuốn sách này T. Harv Eker sẽ tiết lộ những bí mật tại sao một số người lại đạt được những thành công vượt bậc, được số phận ban cho cuộc sống sung túc, giàu có, trong khi một số người khác phải chật vật, vất vả mới có một cuộc sống qua ngày. Bạn sẽ hiểu được nguồn gốc sự thật và những yếu tố quyết định thành công, thất bại để rồi áp dụng, thay đổi cách suy nghĩ, lên kế hoạch rồi tìm ra cách làm việc, đầu tư, sử dụng nguồn tài chính của bạn theo hướng hiệu quả nhất.', 'img/product_img/bi_mat_tu_duy.jpg'),
(N'Nghĩ Giàu & Làm Giàu (Tái Bản 2020)', 2, 80000, 8, N'Think and Grow Rich - Nghĩ giàu và làm giàu là một trong những cuốn sách bán chạy nhất mọi thời đại. Đã hơn 60 triệu bản được phát hành với gần trăm ngôn ngữ trên toàn thế giới và được công nhận là cuốn sách tạo ra nhiều triệu phú, một cuốn sách truyền cảm hứng thành công nhiều hơn bất cứ cuốn sách kinh doanh nào trong lịch sử.', 'img/product_img/nghi_giau_lam_giau.jpg'),
(N'Người Giàu Có Nhất Thành Babylon', 2, 71000, 8, N'Để những nguyện vọng của mình được thực hiện, ít nhất bạn phải thành công về mặt tiền bạc. Quyển sách này sẽ giúp bạn biết cách vận dụng những nguyên lý quan trọng để phát triển tài chính. Hãy để cuốn sách dẫn dắt bạn đi từ một hoàn cảnh khó khăn, tiêu biểu là một cái túi lép xẹp, đến một cuộc sống đầy đủ và hạnh phúc, tiêu biểu là một túi tiền căng phồng, sung túc.', 'img/product_img/nguoi_giau_co_nhat.jpg'),
(N'D. Trump - Nghệ Thuật Đàm Phán (Tái Bản 2020)', 2, 92000, 8, N'Quyển sách cho chúng ta thấy cách Trump làm việc mỗi ngày - cách ông điều hành công việc kinh doanh và cuộc sống - cũng như cách ông trò chuyện với bạn bè và gia đình, làm ăn với đối thủ, mua thành công những sòng bạc hàng đầu ở thành phố Atlantic, thay đổi bộ mặt của những cao ốc ở thành phố New York… và xây dựng những tòa nhà chọc trời trên thế giới.', 'img/product_img/nghe_thuat_dam_phan.jpg'),
(N'Atomic Habits - Thay Đổi Tí Hon Hiệu Quả Bất Ngờ', 3, 141000, 8, N'Một thay đổi tí hon có thể biến đổi cuộc đời bạn không? Hẳn là khó đồng ý với điều đó. Nhưng nếu bạn thay đổi thêm một chút? Một chút nữa? Rồi thêm một chút nữa? Đến một lúc nào đó, bạn phải công nhận rằng cuộc sống của mình đã chuyển biến nhờ vào một thay đổi nhỏ…', 'img/product_img/atomic_habits.jpg'),
(N'Con Đường Chẳng Mấy Ai Đi', 3, 99000, 8, N'Có lẽ không quyển sách nào trong thế kỷ này có tác động sâu sắc đến đời sống trí tuệ và tinh thần của chúng ta hơn Con Đường Chẳng Mấy Ai Đi. Với doanh số trên 10 triệu bản in trên toàn thế giới và được dịch sang hơn 25 ngôn ngữ, đây là một hiện tượng trong ngành xuất bản, với hơn mười năm nằm trong danh sách Best-sellers của New York Times.', 'img/product_img/con_duong_chang_may_ai_di.jpg'),
(N'Manifest - 7 Bước Để Thay Đổi Cuộc Đời Bạn Mãi Mãi', 3, 62000, 8, N'Mở ra cánh cửa Manifest và giải phóng tiềm năng vô hạn của chính mình cùng cuốn sách MANIFEST – 7 bước để thay đổi cuộc đời bạn mãi mãi.', 'img/product_img/manifest.jpg'),
(N'Được Học (Tái Bản 2022)', 3, 145000, 8, N'Cô bé Tara sống trên núi, đã vậy còn chưa bao giờ được đi học bởi vì bố của Tara – một người quyết liệt bài bác trường công cũng như bất cứ khía cạnh văn minh nào “phản tự nhiên”, phản lại ý Chúa – muốn như thế. Thậm chí cô bé này không có cả giấy khai sinh, nghĩa là trong hệ thống xã hội cô không tồn tại. Tara tồn tại theo “luật” của bố: cô được định nghĩa qua những công việc nhằm sửa soạn cho ngày Tận thế, những lao động khổ ải ở bãi phế liệu, và trên hết là nề nếp khắc kỷ tuyệt đối thể hiện lòng sùng kính Chúa.', 'img/product_img/duoc_hoc.jpg'),
(N'Khi Mọi Điều Không Như Ý', 3, 76000, 8, N'Từ nỗi mất mát, đau khổ và cô đơn của những trải nghiệm không như ý - trong cuốn sách ấm áp này - Đại đức Hae Min ân cần dẫn dắt chúng ta tới nhận thức rằng những khoảnh khắc ấy thực sự có thể là cơ hội hiếm có để khám phá bản thân, đóng vai trò là bước đệm cho những điều lớn lao hơn trong cuộc sống.', 'img/product_img/khi_moi_dieu.jpg'),
(N'Stop Overthinking - Sống Tự Do, Không Âu Lo', 3, 66000, 8, N'Stop Overthinking - Sống Tự Do, Không Âu Lo là một cuốn sách hữu ích và thiết thực dành cho bất kỳ ai muốn thoát khỏi vòng xoáy suy nghĩ tiêu cực và bắt đầu sống một cuộc sống tích cực hơn. Đừng để suy nghĩ quá mức kiểm soát cuộc sống của bạn. Hãy đọc Stop Overthinking - Sống Tự Do, Không Âu Lo ngay hôm nay và bắt đầu hành trình hướng tới một cuộc sống hạnh phúc và viên mãn hơn bạn nhé!', 'img/product_img/stop_overthinking.jpg'),
(N'Lược Sử Nước Việt Bằng Tranh (Tái Bản 2024)', 4, 112000, 8, N'Dòng sử Việt trôi xuôi từ thượng nguồn lịch sử, thuở cha Lạc Long Quân kết duyên cùng mẹ Âu Cơ.Từ quá khứ xa xưa đẫm màu huyền tích, nước Việt đã trải qua xiết bao biến cố thăng trầm. Những dấu chân cha ông từ ngày mở nước vẫn còn lưu lại trong thẳm sâu tâm hồn dân tộc.Và ta hãy tìm xem, những bóng dáng nào của ngày hôm qua vẫn còn thấp thoáng trong dòng chảy hôm nay…', 'img/product_img/luoc_su_vn.jpg'),
(N'Búp Sen Xanh (Tái Bản 2020)', 4, 57000, 8, N'“Búp Sen Xanh” là nơi tiểu thuyết và lịch sử đã gặp nhau và hoạ nên một giai đoạn trong cuộc đời người Cha già của dân tộc Việt Nam. Nơi ấy, có quê nhà xứ Nghệ, có làng Sen, có khung dệt của mẹ, có lời dạy của cha, có những người bạn và những kỷ niệm ấu thơ. Nơi ấy có xứ Huế mà trong cuộc sống nghèo khổ có trăn trở tuổi trẻ, về con người, về vận mệnh dân tộc, có mất mát và đau thương...', 'img/product_img/bup_sen_xanh.jpg'),
(N'Lớp Học Mật Ngữ - Tập Đặc Biệt Kỷ Niệm 10 Năm', 4, 51000, 8, N'Thân mời bạn đi “dự tiệc bên cồn” đầu Xuân mới cùng các cung hoàng đạo trong phần 2 của ấn phẩm Lớp Học Mật Ngữ tập đặc biệt kỷ niệm 10 năm. Không hề “phông bạt”, ở đây chỉ có một “bộ truyện thư giãn” dành cho các “quạt”!', 'img/product_img/lop_hoc_mat_ngu.jpg'),
(N'Tuổi Thơ Dữ Dội - Tập 1 (Tái Bản 2019)', 4, 56000, 8, N'“Tuổi Thơ Dữ Dội” là một câu chuyện hay, cảm động viết về tuổi thơ. Sách dày 404 trang mà người đọc không bao giờ muốn ngừng lại, bị lôi cuốn vì những nhân vật ngây thơ có, khôn ranh có, anh hùng có, vì những sự việc khi thì ly kỳ, khi thì hài hước, khi thì gây xúc động đến ứa nước mắt...', 'img/product_img/tuoi_tho_du_doi.jpg'),
(N'Tuổi Thơ Dữ Dội - Tập 2 (Tái Bản 2019)', 4, 67000, 8, N'“Tuổi Thơ Dữ Dội” là một câu chuyện hay, cảm động viết về tuổi thơ. Sách dày 404 trang mà người đọc không bao giờ muốn ngừng lại, bị lôi cuốn vì những nhân vật ngây thơ có, khôn ranh có, anh hùng có, vì những sự việc khi thì ly kỳ, khi thì hài hước, khi thì gây xúc động đến ứa nước mắt...', 'img/product_img/tuoi_tho.jpg'),
(N'Giáo Trình Chuẩn HSK 1 (Tái Bản 2023)', 5, 128000, 8, N'• Kết hợp thi cử và giảng dạy: Được biên soạn phù hợp với nội dung, hình thức cũng như các cấp độ của đề thi HSK thật, bộ sách này có thể được sử dụng đồng thời cho cả hai mục đích là giảng dạy tiếng Trung Quốc và luyện thi HSK. • Bố cục chặt chẽ và khoa học: Các điểm ngữ pháp được giải thích cặn kẽ, phần ngữ âm và chữ Hán được trình bày từ đơn giản đến phức tạp theo từng cấp độ.', 'img/product_img/hsk1.jpg'),
(N'Giáo Trình Chuẩn HSK 1 - Sách Bài Tập (Tái Bản 2023)', 5, 102000, 8, N'Kết hợp thi cử và giảng dạy:Được biên soạn phù hợp với nội dung, hình thức cũng như các cấp độ của đề thi HSK thật, bộ sách này có thể được sử dụng đồng thời cho cả hai mục đích là giảng dạy tiếng Trung Quốc và luyện thi HSK.', 'img/product_img/hsk1_sbt.jpg'),
(N'Giáo Trình Chuẩn YCT 1 (CD)', 5, 96000, 8, N'Bài thi tiếng Trung Quốc dành cho học sinh (Youth Chinese Test – YCT) là bài kiểm tra chuẩn ở cấp độ quốc tế về trình độ tiếng Trung Quốc. Bài thi này đánh giá khả năng sử dụng tiếng Trung Quốc trong cuộc sống hằng ngày cũng như trong học tập của học sinh tiểu học và trung học cơ sở có ngôn ngữ mẹ đẻ không phải là tiếng Trung Quốc. Bộ sách Giáo trình chuẩn YCT được biên soạn theo hướng bám sát các bài thi YCT đồng thời dựa trên nguyên tắc kết hợp giảng dạy và kiểm tra.', 'img/product_img/yct.jpg'),
(N'Giáo Trình Chuẩn HSK 4 - Tập 1', 5, 148000, 8, N'Kết hợp thi cử và giảng dạy: Được biên soạn phù hợp với nội dung, hình thức cũng như các cấp độ của đề thi HSK thật, bộ sách này có thể được sử dụng đồng thời cho cả hai mục đích là giảng dạy tiếng Trung Quốc và luyện thi HSK.', 'img/product_img/hsk41.jpg'),
(N'Giáo Trình Chuẩn HSK 2 - Bài Học', 5, 127000, 8, N'Kết hợp thi cử và giảng dạy: Được biên soạn phù hợp với nội dung, hình thức cũng như các cấp độ của đề thi HSK thật, bộ sách này có thể được sử dụng đồng thời cho cả hai mục đích là giảng dạy tiếng Trung Quốc và luyện thi HSK.', 'img/product_img/hsk2.jpg'),
(N'Giúp Trí Nhớ Ngữ Pháp Tiếng Anh Và Động Từ Bất Quy Tắc', 5, 4900, 8, N'Giúp Trí Nhớ Ngữ Pháp Tiếng Anh Và Động Từ Bất Quy Tắc', 'img/product_img/bang_tri_nho.jpg');

CREATE TABLE orders (
    order_id INT PRIMARY KEY IDENTITY(1,1),
    customer_id INT FOREIGN KEY REFERENCES customers(customer_id),
    order_date DATETIME NOT NULL,
    total_amount DECIMAL(18, 2) NOT NULL,
    [status] NVARCHAR(50) NOT NULL -- e.g., Pending, Completed, Cancelled
);

----------
INSERT INTO orders (customer_id, order_date, total_amount, [status]) VALUES
(1, '2023-11-01 08:00:00', 290000, 'processing'),
(2, '2023-11-02 08:00:00', 285000, 'processing'),
(3, '2023-11-03 08:00:00', 365000, 'processing'),
(4, '2023-11-04 08:00:00', 280000, 'processing'),
(5, '2023-11-05 08:00:00', 275000, 'processing'),
(6, '2023-11-06 08:00:00', 240000, 'processing'),
(7, '2023-11-07 08:00:00', 310000, 'shipping'),
(8, '2023-11-08 08:00:00', 340000, 'shipping'),
(9, '2023-11-09 08:00:00', 600000, 'shipping'),
(10, '2023-11-10 08:00:00', 280000, 'shipping'),
(11, '2023-11-11 08:00:00', 390000, 'shipping'),
(12, '2023-11-12 08:00:00', 500000, 'shipping'),
(13, '2023-11-13 08:00:00', 400000, 'shipping'),
(14, '2023-11-14 08:00:00', 185000, 'shipping'),
(15, '2023-11-15 08:00:00', 290000, 'shipping'),
(16, '2023-11-16 08:00:00', 290000, 'done'),
(17, '2023-11-17 08:00:00', 300000, 'done'),
(18, '2023-11-18 08:00:00', 460000, 'done'),
(19, '2023-11-19 08:00:00', 400000, 'done'),
(20, '2023-11-20 08:00:00', 420000, 'done'),
(21, '2023-11-21 08:00:00', 350000, 'done'),
(22, '2023-11-22 08:00:00', 230000, 'done'),
(23, '2023-11-23 08:00:00', 230000, 'done'),
(24, '2023-11-24 08:00:00', 255000, 'done'),
(25, '2023-11-25 08:00:00', 270000, 'done'),
(26, '2023-11-26 08:00:00', 275000, 'done'),
(27, '2023-11-27 08:00:00', 290000, 'canceled'),
(28, '2023-11-28 08:00:00', 245000, 'canceled'),
(29, '2023-11-29 08:00:00', 350000, 'canceled'),
(30, '2023-11-16 08:00:00', 280000, 'canceled'),
(1, '2023-11-17 15:39:31', 550000, 'shipping'),
(1, '2023-11-18 15:51:43', 600000, 'done'),
(1, '2023-11-22 15:53:02', 370000, 'shipping'),
(1, '2023-11-27 09:34:21', 460000, 'done');


CREATE TABLE order_details (
    order_detail_id INT PRIMARY KEY IDENTITY(1,1),
    order_id INT FOREIGN KEY REFERENCES orders(order_id),
    book_id INT FOREIGN KEY REFERENCES books(book_id),
    quantity INT NOT NULL,
    unit_price DECIMAL(18, 2) NOT NULL,
    subtotal DECIMAL(18, 2) NOT NULL
);

-----------------------
INSERT INTO order_details (order_id, book_id, quantity, unit_price, subtotal) VALUES
(1, 1, 2, 67000, 134000),  -- Order 1: 2 Vịt nguyên con
(1, 2, 1, 65000, 65000),   -- Order 1: 1 Ức vịt
(2, 3, 1, 310000, 310000),  -- Order 2: 1 Phi lê vịt có da
(3, 4, 1, 365000, 365000),  -- Order 3: 1 Phi lê vịt không da
(4, 1, 3, 67000, 201000),   -- Order 4: 3 Vịt nguyên con
(4, 2, 1, 65000, 65000),    -- Order 4: 1 Ức vịt
(5, 3, 1, 310000, 310000),  -- Order 5: 1 Phi lê vịt có da
(6, 4, 1, 365000, 365000),  -- Order 6: 1 Phi lê vịt không da
(7, 1, 2, 67000, 134000),   -- Order 7: 2 Vịt nguyên con
(7, 2, 2, 65000, 130000),   -- Order 7: 2 Ức vịt
(8, 3, 1, 310000, 310000),  -- Order 8: 1 Phi lê vịt có da
(9, 4, 2, 365000, 730000),  -- Order 9: 2 Phi lê vịt không da
(10, 1, 1, 67000, 67000),   -- Order 10: 1 Vịt nguyên con
(11, 2, 3, 65000, 195000),  -- Order 11: 3 Ức vịt
(12, 3, 2, 310000, 620000), -- Order 12: 2 Phi lê vịt có da
(13, 4, 1, 365000, 365000), -- Order 13: 1 Phi lê vịt không da
(14, 1, 1, 67000, 67000),   -- Order 14: 1 Vịt nguyên con
(15, 2, 2, 65000, 130000),  -- Order 15: 2 Ức vịt
(16, 3, 1, 310000, 310000), -- Order 16: 1 Phi lê vịt có da
(17, 4, 1, 365000, 365000), -- Order 17: 1 Phi lê vịt không da
(18, 1, 3, 67000, 201000),  -- Order 18: 3 Vịt nguyên con
(19, 2, 2, 65000, 130000),  -- Order 19: 2 Ức vịt
(20, 3, 1, 310000, 310000), -- Order 20: 1 Phi lê vịt có da
(21, 4, 1, 365000, 365000), -- Order 21: 1 Phi lê vịt không da
(22, 1, 2, 67000, 134000),  -- Order 22: 2 Vịt nguyên con
(23, 2, 1, 65000, 65000),   -- Order 23: 1 Ức vịt
(24, 3, 1, 310000, 310000), -- Order 24: 1 Phi lê vịt có da
(25, 4, 1, 365000, 365000), -- Order 25: 1 Phi lê vịt không da
(26, 1, 1, 67000, 67000),   -- Order 26: 1 Vịt nguyên con
(27, 2, 2, 65000, 130000),  -- Order 27: 2 Ức vịt
(28, 3, 1, 310000, 310000), -- Order 28: 1 Phi lê vịt có da
(29, 4, 1, 365000, 365000), -- Order 29: 1 Phi lê vịt không da
(30, 1, 2, 67000, 134000),  -- Order 30: 2 Vịt nguyên con
(31, 2, 3, 65000, 195000),  -- Order 31: 3 Ức vịt
(32, 3, 2, 310000, 620000), -- Order 32: 2 Phi lê vịt có da
(33, 4, 1, 365000, 365000), -- Order 33: 1 Phi lê vịt không da
(34, 1, 1, 67000, 67000);   -- Order 34: 1 Vịt nguyên con


CREATE TABLE stores (
    store_id INT PRIMARY KEY IDENTITY(1,1),
    store_name NVARCHAR(100) NOT NULL,
    [address] NVARCHAR(255),
    phone_number NVARCHAR(15),
    email NVARCHAR(100),

);

INSERT INTO stores (store_name, [address], phone_number, email) VALUES
(N'Book', N'123 Lê Lợi, Hà Nội', '0256123456', 'store1@flowerstore.com'),
(N'Book Đà Nẵng', N'456 Trần Hưng Đạo, Đà Nẵng', '0256234567', 'store2@flowerstore.com'),
(N'Book Sài Gòn', N'789 Nguyễn Huệ, TPHCM', '0256345678', 'store3@flowerstore.com');

CREATE TABLE store_inventory (
    id INT PRIMARY KEY IDENTITY(1,1),
    store_id INT FOREIGN KEY REFERENCES stores(store_id),
    book_id INT FOREIGN KEY REFERENCES books(book_id),
    stock_quantity INT NOT NULL
);

INSERT INTO store_inventory (store_id, book_id, stock_quantity) VALUES
(1, 1, 20),  -- Cửa hàng 1 có 20 Hoa Cát Tường
(1, 2, 15),  -- Cửa hàng 1 có 15 Hoa Hồng
(1, 3, 10),  -- Cửa hàng 1 có 10 Hoa Oải Hương
(2, 4, 12),  -- Cửa hàng 2 có 12 Hoa Hướng Dương
(2, 1, 8),   -- Cửa hàng 2 có 8 Hoa Loa Kèn Trắng
(2, 2, 9),   -- Cửa hàng 2 có 9 Hoa Cẩm Chướng
(3, 3, 11),  -- Cửa hàng 3 có 11 Hoa Lay Ơn
(3, 4, 6),   -- Cửa hàng 3 có 6 Hoa Lan Hồ Điệp
(3, 1, 10);  -- Cửa hàng 3 có 10 Hoa Tulip Xanh


CREATE TABLE employees (
    employee_id INT PRIMARY KEY IDENTITY(1,1),
    full_name NVARCHAR(100) NOT NULL,
    phone_number NVARCHAR(15),
    email NVARCHAR(100),
    [address] NVARCHAR(255),
    store_id INT FOREIGN KEY REFERENCES stores(store_id), -- Links employee to a specific store
	[username] NVARCHAR(50) NOT NULL,
    [password] NVARCHAR(255) NOT NULL, -- Lưu trữ mật khẩu đã được băm
);

INSERT INTO employees (full_name, phone_number, email, [address], store_id, [username], [password]) VALUES
(N'Nguyễn Thế Quyền', '0256111111', 'nva@flowerstore.com', N'123 Lê Lợi, Quy Nhơn, Bình Định', 1, 'ntq', '123456'),
(N'Trần Thị B', '0256222222', 'ttb@flowerstore.com', N'456 Trần Hưng Đạo, Quy Nhơn, Bình Định', 1, 'ttb', '123456'),
(N'Lê Văn C', '0256333333', 'lvc@flowerstore.com', N'789 Nguyễn Huệ, An Nhơn, Bình Định', 2, 'lvc', '123456'),
(N'Phạm Thị D', '0256444444', 'ptd@flowerstore.com', N'321 Lý Thường Kiệt, Quy Nhơn, Bình Định', 2, 'ptd', '123456'),
(N'Hoàng Văn E', '0256555555', 'hve@flowerstore.com', N'654 Ngô Quyền, An Nhơn, Bình Định', 3, 'hve', '123456'),
(N'Võ Thị F', '0256666666', 'vtf@flowerstore.com', N'987 Lê Duẩn, Quy Nhơn, Bình Định', 3, 'vtf', '123456');